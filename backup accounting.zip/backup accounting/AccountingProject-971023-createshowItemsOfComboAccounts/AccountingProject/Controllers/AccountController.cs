using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AccountingProject.Models;
using AccountingProject.Models.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace AccountingProject.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceprovider;
        public AccountController(ApplicationDbContext context, IServiceProvider iserviceprovider)
        {
            _context = context;
            _iserviceprovider = iserviceprovider;
        }
        [HttpGet]
        public IActionResult Index()
        {
            AddAccountViewModel model = new AddAccountViewModel();
            model.AccountGroup = _context.accountgroups.Select(ag => new SelectListItem
            {
                Text = ag.AccountGroupName,
                Value=ag.AccountGroupID.ToString()
            }).ToList();
            model.KolAccount = _context.kolaccounts.Select(ag => new SelectListItem
            {
                Text = ag.KolAccountName,
                Value = ag.KolAccountID.ToString()
            }).ToList();
            model.MoeenAccount = _context.moeenaccounts.Select(ag => new SelectListItem
            {
                Text = ag.MoeenAccountName,
                Value = ag.MoeenAccountID.ToString()
            }).ToList();
            model.FirstTafziliAccount = _context.firsttafziliaccounts.Select(ag => new SelectListItem
            {
                Text = ag.FirstTafziliAccountName,
                Value = ag.FirstTafziliAccountID.ToString()
            }).ToList();
            model.SecondTafziliAccount = _context.secondtafziliaccounts.Select(ag => new SelectListItem
            {
                Text = ag.SecondTafziliAccountName,
                Value = ag.SecondTafziliAccountID.ToString()
            }).ToList();
            return View(model);
        }
    }
}