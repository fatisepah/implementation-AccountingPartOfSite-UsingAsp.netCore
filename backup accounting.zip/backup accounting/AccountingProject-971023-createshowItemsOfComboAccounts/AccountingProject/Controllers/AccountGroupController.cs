using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AccountingProject.Models;

namespace AccountingProject.Controllers
{
    public class AccountGroupController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceprovider;
        public AccountGroupController(ApplicationDbContext context, IServiceProvider iserviceprovider)
        {
            _context = context;
            _iserviceprovider = iserviceprovider;
        }
        [HttpGet]
        public IActionResult Index()
        {
            List<AccountGroup> model = new List<AccountGroup>();
            model = _context.accountgroups.Select(ag => new AccountGroup
            {
                AccountGroupID=ag.AccountGroupID,
                AccountGroupName=ag.AccountGroupName
            }).ToList();
            return View(model);
        }
    }
}