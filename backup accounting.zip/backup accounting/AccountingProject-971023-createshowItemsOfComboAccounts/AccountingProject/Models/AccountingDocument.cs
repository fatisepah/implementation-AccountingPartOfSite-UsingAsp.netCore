﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AccountingProject.Models
{
    public class AccountingDocument
    {
        [Key]
        public int AccountingDocumentID { get; set; }
        [Display(Name = "تاریخ")]
        [Required(ErrorMessage = "لطفا تاریخ را وارد کنید.")]
        public DateTime AccountingDocumentDate { get; set; }

        [Display(Name = "وضعیت سند")]
        [Required(ErrorMessage = "لطفا وضعیت سند را وارد کنید.")]
        public string DocumentStatus { get; set; }

        [Display(Name = "تنظیم کننده")]
       // [Required(ErrorMessage = "لطفا تنظیم کننده را وارد کنید.")]
        public string Regularizer { get; set; }

        [Display(Name = "شرح سند")]
        [Required(ErrorMessage = "لطفا شرح سند را وارد کنید.")]
        public string DocumentDescription { get; set; }

        [Display(Name = "جمع مبالغ حسابهای بدهکار")]
        [Required(ErrorMessage = "لطفا جمع مبالغ حسابهای بدهکار را وارد کنید.")]
        public int SumOfDebtorAccount { get; set; }

        [Display(Name = "جمع مبالغ حسابهای بستانکار")]
        [Required(ErrorMessage = "لطفا جمع مبالغ حسابهای بستانکار را وارد کنید.")]
        public int SumOfCreditorAccount { get; set; }
    }
}
