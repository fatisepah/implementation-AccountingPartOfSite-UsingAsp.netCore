﻿using AccountingProject.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AccountingProject.Models
{
    public class DocumentAccounts
    {
        [Key]
        public int DocumentAccountsID { get; set; }

        
        //foriegn key for AccountingDocument table
        public int AccountingDocumentID { get; set; }
        [ForeignKey("AccountingDocumentID")]
        public virtual AccountingDocument accountingdocuments { get; set; }



        //foriegn key for AccountViewModel
        public int AccountID { get; set; }
        [ForeignKey("AccountID")]
        public virtual AddAccountViewModel accountviewModels { get; set; }



        [Display(Name = "مبلغ بستانکاری")]
        [Required(ErrorMessage = "لطفا مبلغ بستانکاری را وارد کنید.")]
        public int AmountOfCredit { get; set; }


        [Display(Name = "مبلغ بدهکاری")]
        [Required(ErrorMessage = "لطفا مبلغ بدهکاری را وارد کنید.")]
        public int AmountOfDebt { get; set; }


        //[Display(Name = "تشخیص")]
        //[Required(ErrorMessage = "لطفا تشخیص را وارد کنید.")]
        //public string DebtOrCredit { get; set; }
    }
}
