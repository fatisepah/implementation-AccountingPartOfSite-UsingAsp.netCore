﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AccountingProject.Models
{
    public class FirstTafziliAccount
    {
        [Key]
        public int FirstTafziliAccountID { get; set; }

        [Display(Name = "نام حساب تفضیلی1")]
        [Required(ErrorMessage = "لطفا نام حساب تفضیلی1 را وارد کنید.")]
        public string FirstTafziliAccountName { get; set; }

        public int MoeenAccountID { get; set; }


        //forien key for MoeenAccount table
        [ForeignKey("MoeenAccountID")]
        public virtual MoeenAccount moeenaccounts { get; set; }

    }
}
