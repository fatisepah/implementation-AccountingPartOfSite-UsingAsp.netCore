﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AccountingProject.Models
{
    public class MoeenAccount
    {
        [Key]
        public int MoeenAccountID { get; set; }

        [Display(Name ="نام حساب معین")]
        [Required(ErrorMessage ="لطفا نام حساب معین را وارد کنید.")]
        public string MoeenAccountName { get; set; }

        public int KolAccountID { get; set; }


        //forien key for KolAccount table
        [ForeignKey("KolAccountID")]
        public virtual KolAccount kolaccounts { get; set; }

    }
}
