﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AccountingProject.Models
{
    public class SecondTafziliAccount
    {
        [Key]
        public int SecondTafziliAccountID { get; set; }

        [Display(Name = "نام حساب تفضیلی2")]
        [Required(ErrorMessage = "لطفا نام حساب تفضیلی2 را وارد کنید.")]
        public string SecondTafziliAccountName { get; set; }

        public int FirstTafziliAccountID { get; set; }


        //forien key for FirstTTafziliAccount table
        [ForeignKey("FirstTafziliAccountID")]
        public virtual FirstTafziliAccount firsttafziliaccounts { get; set; }
    }
}
