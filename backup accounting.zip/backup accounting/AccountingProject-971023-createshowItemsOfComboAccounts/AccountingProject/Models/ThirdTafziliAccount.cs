﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AccountingProject.Models
{
    public class ThirdTafziliAccount
    {
        [Key]
        public int ThirdTafziliAccountID { get; set; }

        [Display(Name = "نام حساب تفضیلی3")]
        [Required(ErrorMessage = "لطفا نام حساب تفضیلی3 را وارد کنید.")]
        public string ThirdTafziliAccountName { get; set; }

        public int SecondTafziliAccountID { get; set; }


        //forien key for SecondTafziliAccount table
        [ForeignKey("SecondTafziliAccountID")]
        public virtual SecondTafziliAccount secondtafziliaccounts { get; set; }
    }
}
