﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AccountingProject.Models.ViewModels
{
    public class AddAccountViewModel
    {
        [Key]
        public int ID { get; set; }

        /// <summary>
        /// ////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        [Display(Name = "نام گروه حساب")]
        /// 
        public int AccountGroupID { get; set; }
        /// 
        public List<SelectListItem> AccountGroup { get; set; }
        /// <summary>
        /// ///////////////////////////////////////////////////////////////////////////////
        /// </summary>
        [Display(Name = "نام حساب کل")]
        /// 
        public int KolAccountID { get; set; }
        /// 
        public List<SelectListItem> KolAccount { get; set; }
        /// 
        /// <summary>
        /// //////////////////////////////////////////////////////////////////////////////
        /// </summary>
        [Display(Name = "نام حساب معین")]
        /// 
        public int MoeenAccountID { get; set; }
        /// 
        public List<SelectListItem> MoeenAccount { get; set; }



        /// <summary>
        /// ///////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// 
        [Display(Name = "نام حساب تفضیلی1")]

        public int FirstTafziliAccountID { get; set; }
        public List<SelectListItem> FirstTafziliAccount { get; set; }


        /// <summary>
        /// ///////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// 
        [Display(Name = "نام حساب تفضیلی2")]

        public int SecondTafziliAccountID { get; set; }
        public List<SelectListItem> SecondTafziliAccount { get; set; }



        /// <summary>
        /// //////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// 
        [Display(Name = "نام حساب تفضیلی3")]
        /// 
        public int ThirdTafziliAccountID { get; set; }
        public List<SelectListItem> ThirdTafziliAccount { get; set; }

        //////////////////////////////////////////////////////////////////////////
        [Display(Name = " کد حساب ")]
        [Required(ErrorMessage = "لطفا کد حساب را وارد کنید.")]
        public int AccountID { get; set; }
        [Display(Name = "نام حساب ")]
        [Required(ErrorMessage = "لطفا نام حساب را وارد کنید.")]
        public string AccountName { get; set; }
    }
}
