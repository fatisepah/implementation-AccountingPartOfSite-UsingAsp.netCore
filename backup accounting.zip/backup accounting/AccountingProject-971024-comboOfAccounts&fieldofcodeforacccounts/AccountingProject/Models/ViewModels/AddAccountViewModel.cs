﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AccountingProject.Models.ViewModels
{
    public class AddAccountViewModel
    {
        [Key]
        public int ID { get; set; }



        [Display(Name = "کد گروه حساب")]
        public int AccountGroupID { get; set; }

        [Display(Name = "نام گروه حساب")]
        public string AccountGroupName { get; set; }

        public List<AccountGroup> AccountGroup { get; set; }





        [Display(Name = "کد حساب کل")]
        public int KolAccountID { get; set; }


        [Display(Name = "نام حساب کل")]
        public string KolAccountName { get; set; }

        public List<KolAccount> KolAccount { get; set; }






        [Display(Name = "کد حساب معین")]
        public int MoeenAccountID { get; set; }

        [Display(Name = "نام حساب معین")]
        public string MoeenAccountName { get; set; }

        public List<MoeenAccount> MoeenAccount { get; set; }






        [Display(Name = "کد حساب تفضیلی1")]
        public int FirstTafziliAccountID { get; set; }

        [Display(Name = "نام حساب تفضیلی1")]
        public string FirstTafziliAccountName { get; set; }

        public List<FirstTafziliAccount> FirstTafziliAccount { get; set; }





   
        [Display(Name = "کد حساب تفضیلی2")]
        public int SecondTafziliAccountID { get; set; }

        [Display(Name = "نام حساب تفضیلی2")]
        public string SecondTafziliAccountName { get; set; }

        public List<SecondTafziliAccount> SecondTafziliAccount { get; set; }






        [Display(Name = "کد حساب تفضیلی3")]
        public int ThirdTafziliAccountID { get; set; }

        [Display(Name = "نام حساب تفضیلی3")]
        public string ThirdTafziliAccountName { get; set; }

        public List<ThirdTafziliAccount> ThirdTafziliAccount { get; set; }




        //////////////////////////////////////////////////////////////////////////
        [Display(Name = " کد حساب ")]
        [Required(ErrorMessage = "لطفا کد حساب را وارد کنید.")]
        public int AccountID { get; set; }


        [Display(Name = "نام حساب ")]
        [Required(ErrorMessage = "لطفا نام حساب را وارد کنید.")]
        public string AccountName { get; set; }
    }
}
