using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AccountingProject.Models;
using AccountingProject.Models.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace AccountingProject.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceprovider;
        public AccountController(ApplicationDbContext context, IServiceProvider iserviceprovider)
        {
            _context = context;
            _iserviceprovider = iserviceprovider;
        }
        [HttpGet]
        public IActionResult Index()
        {
            AddAccountViewModel model = new AddAccountViewModel();

            model.AccountGroup = _context.accountgroups.ToList();
            model.KolAccount = _context.kolaccounts.ToList();
            model.MoeenAccount = _context.moeenaccounts.ToList();
            model.FirstTafziliAccount = _context.firsttafziliaccounts.ToList();
            model.SecondTafziliAccount = _context.secondtafziliaccounts.ToList();

            //ViewBag.AccountGroup = _context.accountgroups.ToList();
            //ViewBag.KolAccount = _context.kolaccounts.ToList();
            //ViewBag.MoeenAccount = _context.moeenaccounts.ToList();
            //ViewBag.FirstTafziliAccount = _context.firsttafziliaccounts.ToList();
            //ViewBag.SecondTafziliAccount = _context.secondtafziliaccounts.ToList();


            return View(model);
        }
        [HttpGet]
        public IActionResult ShowListAccount()
        {
            List<AddAccountViewModel> model = new List<AddAccountViewModel>();
            var query = (from a in _context.accounts
                         join ag in _context.accountgroups on a.AccountGroupID equals ag.AccountGroupID
                         join k in _context.kolaccounts on a.KolAccountID equals k.KolAccountID
                         join m in _context.moeenaccounts on a.MoeenAccountID equals m.MoeenAccountID
                         join ft in _context.firsttafziliaccounts on a.FirstTafziliAccountID equals ft.FirstTafziliAccountID
                         join st in _context.secondtafziliaccounts on a.SecondTafziliAccountID equals st.SecondTafziliAccountID
                         join tt in _context.thirdtafziliaccounts on a.ThirdTafziliAccountID equals tt.ThirdTafziliAccountID
                         select new
                         {
                             ag.AccountGroupID,
                             ag.AccountGroupName,
                             k.KolAccountID,
                             k.KolAccountName,
                             m.MoeenAccountID,
                             m.MoeenAccountName,
                             ft.FirstTafziliAccountID,
                             ft.FirstTafziliAccountName,
                             st.SecondTafziliAccountID,
                             st.SecondTafziliAccountName,
                             tt.ThirdTafziliAccountID,
                             tt.ThirdTafziliAccountName
                         });
            foreach(var item in query )
            {
                AddAccountViewModel objmodel = new AddAccountViewModel();
                objmodel.AccountGroupID = item.AccountGroupID;
                objmodel.AccountGroupName = item.AccountGroupName;
                objmodel.KolAccountID = item.KolAccountID;
                objmodel.KolAccountName = item.KolAccountName;
                objmodel.MoeenAccountID = item.MoeenAccountID;
                objmodel.MoeenAccountName = item.MoeenAccountName;
                objmodel.FirstTafziliAccountID = item.FirstTafziliAccountID;
                objmodel.FirstTafziliAccountName = item.FirstTafziliAccountName;
                objmodel.SecondTafziliAccountID = item.SecondTafziliAccountID;
                objmodel.SecondTafziliAccountName = item.SecondTafziliAccountName;
                objmodel.ThirdTafziliAccountID = item.ThirdTafziliAccountID;
                objmodel.ThirdTafziliAccountName = item.ThirdTafziliAccountName;

                model.Add(objmodel);
            }




            return View(model);

        }
    }
}