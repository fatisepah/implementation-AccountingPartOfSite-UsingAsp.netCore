﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace AccountingProject.Migrations
{
    public partial class updatedatabase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_documentaccounts_accountviewmodels_AccountID",
                table: "documentaccounts");

            migrationBuilder.DropTable(
                name: "accountviewmodels");

            migrationBuilder.DropIndex(
                name: "IX_documentaccounts_AccountID",
                table: "documentaccounts");

            migrationBuilder.DropColumn(
                name: "AccountID",
                table: "documentaccounts");

            migrationBuilder.AddColumn<int>(
                name: "ThirdTafziliAccountCode",
                table: "thirdtafziliaccounts",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "SecondTafziliAccountCode",
                table: "secondtafziliaccounts",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "MoeenAccountCode",
                table: "moeenaccounts",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "KolAccountCode",
                table: "kolaccounts",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "FirstTafziliAccountCode",
                table: "firsttafziliaccounts",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "AccountGroupCode",
                table: "accountgroups",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ThirdTafziliAccountCode",
                table: "thirdtafziliaccounts");

            migrationBuilder.DropColumn(
                name: "SecondTafziliAccountCode",
                table: "secondtafziliaccounts");

            migrationBuilder.DropColumn(
                name: "MoeenAccountCode",
                table: "moeenaccounts");

            migrationBuilder.DropColumn(
                name: "KolAccountCode",
                table: "kolaccounts");

            migrationBuilder.DropColumn(
                name: "FirstTafziliAccountCode",
                table: "firsttafziliaccounts");

            migrationBuilder.DropColumn(
                name: "AccountGroupCode",
                table: "accountgroups");

            migrationBuilder.AddColumn<int>(
                name: "AccountID",
                table: "documentaccounts",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "accountviewmodels",
                columns: table => new
                {
                    AccountID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AccountGroupID = table.Column<int>(nullable: false),
                    AccountGroupName = table.Column<string>(nullable: false),
                    FirstTafziliAccountID = table.Column<int>(nullable: false),
                    FirstTafziliAccountName = table.Column<string>(nullable: false),
                    KolAccountID = table.Column<int>(nullable: false),
                    KolAccountName = table.Column<string>(nullable: false),
                    MoeenAccountID = table.Column<int>(nullable: false),
                    MoeenAccountName = table.Column<string>(nullable: false),
                    SecondTafziliAccountID = table.Column<int>(nullable: false),
                    SecondTafziliAccountName = table.Column<string>(nullable: false),
                    ThirdTafziliAccountID = table.Column<int>(nullable: false),
                    ThirdTafziliAccountName = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_accountviewmodels", x => x.AccountID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_documentaccounts_AccountID",
                table: "documentaccounts",
                column: "AccountID");

            migrationBuilder.AddForeignKey(
                name: "FK_documentaccounts_accountviewmodels_AccountID",
                table: "documentaccounts",
                column: "AccountID",
                principalTable: "accountviewmodels",
                principalColumn: "AccountID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
