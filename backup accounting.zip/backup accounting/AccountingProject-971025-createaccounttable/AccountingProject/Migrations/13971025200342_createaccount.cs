﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace AccountingProject.Migrations
{
    public partial class createaccount : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "accounts",
                columns: table => new
                {
                    AccountID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AccountGroupID = table.Column<int>(nullable: false),
                    FirstTafziliAccountID = table.Column<int>(nullable: false),
                    KolAccountID = table.Column<int>(nullable: false),
                    MoeenAccountID = table.Column<int>(nullable: false),
                    SecondTafziliAccountID = table.Column<int>(nullable: false),
                    ThirdTafziliAccountID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_accounts", x => x.AccountID);
                    table.ForeignKey(
                        name: "FK_accounts_accountgroups_AccountGroupID",
                        column: x => x.AccountGroupID,
                        principalTable: "accountgroups",
                        principalColumn: "AccountGroupID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_accounts_firsttafziliaccounts_FirstTafziliAccountID",
                        column: x => x.FirstTafziliAccountID,
                        principalTable: "firsttafziliaccounts",
                        principalColumn: "FirstTafziliAccountID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_accounts_kolaccounts_KolAccountID",
                        column: x => x.KolAccountID,
                        principalTable: "kolaccounts",
                        principalColumn: "KolAccountID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_accounts_moeenaccounts_MoeenAccountID",
                        column: x => x.MoeenAccountID,
                        principalTable: "moeenaccounts",
                        principalColumn: "MoeenAccountID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_accounts_secondtafziliaccounts_SecondTafziliAccountID",
                        column: x => x.SecondTafziliAccountID,
                        principalTable: "secondtafziliaccounts",
                        principalColumn: "SecondTafziliAccountID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_accounts_thirdtafziliaccounts_ThirdTafziliAccountID",
                        column: x => x.ThirdTafziliAccountID,
                        principalTable: "thirdtafziliaccounts",
                        principalColumn: "ThirdTafziliAccountID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_accounts_AccountGroupID",
                table: "accounts",
                column: "AccountGroupID");

            migrationBuilder.CreateIndex(
                name: "IX_accounts_FirstTafziliAccountID",
                table: "accounts",
                column: "FirstTafziliAccountID");

            migrationBuilder.CreateIndex(
                name: "IX_accounts_KolAccountID",
                table: "accounts",
                column: "KolAccountID");

            migrationBuilder.CreateIndex(
                name: "IX_accounts_MoeenAccountID",
                table: "accounts",
                column: "MoeenAccountID");

            migrationBuilder.CreateIndex(
                name: "IX_accounts_SecondTafziliAccountID",
                table: "accounts",
                column: "SecondTafziliAccountID");

            migrationBuilder.CreateIndex(
                name: "IX_accounts_ThirdTafziliAccountID",
                table: "accounts",
                column: "ThirdTafziliAccountID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "accounts");
        }
    }
}
