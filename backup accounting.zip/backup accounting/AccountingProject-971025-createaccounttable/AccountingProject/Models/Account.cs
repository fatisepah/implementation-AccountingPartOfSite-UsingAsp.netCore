﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AccountingProject.Models
{
    public class Account
    {
        //[Key]
        //public int AccountID { get; set; }


        ////foriegn key for AccountGroup table
        //public int AccountGroupID { get; set; }
        //[ForeignKey("AccountGroupID")]
        //public virtual AccountGroup accountgroups { get; set; }



        ////forien key for KolAccount table
        //public int KolAccountID { get; set; }
        //[ForeignKey("KolAccountID")]
        //public virtual KolAccount kolaccounts { get; set; }



        ////forien key for MoeenAccount table
        //public int MoeenAccountID { get; set; }
        //[ForeignKey("MoeenAccountID")]
        //public virtual MoeenAccount moeenaccounts { get; set; }



        ////forien key for FirstTTafziliAccount table
        //public int FirstTafziliAccountID { get; set; }
        //[ForeignKey("FirstTafziliAccountID")]
        //public virtual FirstTafziliAccount firsttafziliaccounts { get; set; }



        ////forien key for SecondTafziliAccount table
        //public int SecondTafziliAccountID { get; set; }
        //[ForeignKey("SecondTafziliAccountID")]
        //public virtual SecondTafziliAccount secondtafziliaccounts { get; set; }


        ////forien key for ThirdTafziliAccount table
        //public int ThirdTafziliAccountID { get; set; }
        //[ForeignKey("ThirdTafziliAccountID")]
        //public virtual ThirdTafziliAccount thirdtafziliaccounts { get; set; }


    }
}
