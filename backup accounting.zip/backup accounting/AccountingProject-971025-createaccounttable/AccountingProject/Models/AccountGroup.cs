﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AccountingProject.Models
{
    public class AccountGroup
    {
        [Key]
        public int AccountGroupID { get; set; }

        [Display(Name = "کد گروه حساب")]
        [Required(ErrorMessage = "لطفا کد گروه حساب را وارد کنید.")]
        public int AccountGroupCode { get; set; }

        [Display(Name ="نام گروه حساب")]
        [Required(ErrorMessage ="لطفا نام گروه حساب را وارد کنید.")]
        public string AccountGroupName { get; set; }
    }
}
