﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.SqlServer;
using AccountingProject.Models.ViewModels;

namespace AccountingProject.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> option) : base(option)
        {
        }

        public DbSet<AccountGroup> accountgroups { get; set; }
        public DbSet<KolAccount> kolaccounts { get; set; }
        public DbSet<MoeenAccount> moeenaccounts { get; set; }
        public DbSet<FirstTafziliAccount> firsttafziliaccounts { get; set; }
        public DbSet<SecondTafziliAccount> secondtafziliaccounts { get; set; }
        public DbSet<ThirdTafziliAccount> thirdtafziliaccounts { get; set; }
       // public DbSet<Account> accounts { get; set; }
        public DbSet<DocumentAccounts> documentaccounts { get; set; }
        public DbSet<AccountingDocument> accountingdocuments { get; set; }
        public DbSet<KolBook> kolbooks { get; set; }

    }


}

