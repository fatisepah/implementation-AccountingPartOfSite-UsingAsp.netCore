﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AccountingProject.Models
{
    public class SecondTafziliAccount
    {
        [Key]
        public int SecondTafziliAccountID { get; set; }


        [Display(Name = "کد حساب تفضیلی2")]
        [Required(ErrorMessage = "لطفا کد حساب تفضیلی2 را وارد کنید.")]
        public int SecondTafziliAccountCode { get; set; }


        [Display(Name = "نام حساب تفضیلی2")]
        [Required(ErrorMessage = "لطفا نام حساب تفضیلی2 را وارد کنید.")]
        public string SecondTafziliAccountName { get; set; }



        //forien key for FirstTTafziliAccount table
        public int FirstTafziliAccountID { get; set; }
        [ForeignKey("FirstTafziliAccountID")]
        public virtual FirstTafziliAccount firsttafziliaccounts { get; set; }
    }
}
