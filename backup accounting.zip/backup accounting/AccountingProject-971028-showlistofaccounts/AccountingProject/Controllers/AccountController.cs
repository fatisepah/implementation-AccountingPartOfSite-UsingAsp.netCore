using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AccountingProject.Models;
using AccountingProject.Models.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace AccountingProject.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceprovider;
        public AccountController(ApplicationDbContext context, IServiceProvider iserviceprovider)
        {
            _context = context;
            _iserviceprovider = iserviceprovider;
        }
        [HttpGet]
        public IActionResult Index()
        {
            AddAccountViewModel model = new AddAccountViewModel();

            model.AccountGroup = _context.accountgroups.ToList();
            model.KolAccount = _context.kolaccounts.ToList();
            model.MoeenAccount = _context.moeenaccounts.ToList();
            model.FirstTafziliAccount = _context.firsttafziliaccounts.ToList();
            model.SecondTafziliAccount = _context.secondtafziliaccounts.ToList();

            //ViewBag.AccountGroup = _context.accountgroups.ToList();
            //ViewBag.KolAccount = _context.kolaccounts.ToList();
            //ViewBag.MoeenAccount = _context.moeenaccounts.ToList();
            //ViewBag.FirstTafziliAccount = _context.firsttafziliaccounts.ToList();
            //ViewBag.SecondTafziliAccount = _context.secondtafziliaccounts.ToList();


            return View(model);
        }
        [HttpGet]
        public IActionResult ShowListAccount()
        {
            List<AddAccountViewModel> model = new List<AddAccountViewModel>();


            var query1 = (from ag in _context.accountgroups
                         select new
                         {
                             ag.AccountGroupID,
                             ag.AccountGroupName
                         });

            foreach (var item in query1)
            {
                AddAccountViewModel objmodel = new AddAccountViewModel();
                objmodel.AccountGroupID = item.AccountGroupID;
                objmodel.AccountGroupName = item.AccountGroupName;
                model.Add(objmodel);
            }



            /////////////////////////////////////////////////////////////////////////////////////////////////

            var query2 = (from ag in _context.accountgroups
                          join k in _context.kolaccounts on ag.AccountGroupID equals k.AccountGroupID
                          select new
                          {
                              ag.AccountGroupID,
                              ag.AccountGroupName,
                              k.KolAccountID,
                              k.KolAccountName

                          });

            foreach (var item in query2)
            {
                AddAccountViewModel objmodel = new AddAccountViewModel();
                objmodel.AccountGroupID = item.AccountGroupID;
                objmodel.AccountGroupName = item.AccountGroupName;
                objmodel.KolAccountID = item.KolAccountID;
                objmodel.KolAccountName = item.KolAccountName;
                model.Add(objmodel);
            }


            /////////////////////////////////////////////////////////////////////////////////////////////////


            var query3 = (from ag in _context.accountgroups
                         join k in _context.kolaccounts on ag.AccountGroupID equals k.AccountGroupID
                         join m in _context.moeenaccounts on k.KolAccountID equals m.KolAccountID
                         select new
                         {
                             ag.AccountGroupID,
                             ag.AccountGroupName,
                             k.KolAccountID,
                             k.KolAccountName,
                             m.MoeenAccountID,
                             m.MoeenAccountName
                         });

            foreach (var item in query3)
            {
                AddAccountViewModel objmodel = new AddAccountViewModel();
                objmodel.AccountGroupID = item.AccountGroupID;
                objmodel.AccountGroupName = item.AccountGroupName;
                objmodel.KolAccountID = item.KolAccountID;
                objmodel.KolAccountName = item.KolAccountName;
                objmodel.MoeenAccountID = item.MoeenAccountID;
                objmodel.MoeenAccountName = item.MoeenAccountName;

                model.Add(objmodel);
            }
            ////////////////////////////////////////////////////////////////////////////////////////////////////


            var query4 = (from ag in _context.accountgroups
                         join k in _context.kolaccounts on ag.AccountGroupID equals k.AccountGroupID
                         join m in _context.moeenaccounts on k.KolAccountID equals m.KolAccountID
                         join ft in _context.firsttafziliaccounts on m.MoeenAccountID equals ft.MoeenAccountID
                         select new
                         {
                             ag.AccountGroupID,
                             ag.AccountGroupName,
                             k.KolAccountID,
                             k.KolAccountName,
                             m.MoeenAccountID,
                             m.MoeenAccountName,
                             ft.FirstTafziliAccountID,
                             ft.FirstTafziliAccountName

                         });

            foreach (var item in query4)
            {
                AddAccountViewModel objmodel = new AddAccountViewModel();
                objmodel.AccountGroupID = item.AccountGroupID;
                objmodel.AccountGroupName = item.AccountGroupName;
                objmodel.KolAccountID = item.KolAccountID;
                objmodel.KolAccountName = item.KolAccountName;
                objmodel.MoeenAccountID = item.MoeenAccountID;
                objmodel.MoeenAccountName = item.MoeenAccountName;
                objmodel.FirstTafziliAccountID = item.FirstTafziliAccountID;
                objmodel.FirstTafziliAccountName = item.FirstTafziliAccountName;

                model.Add(objmodel);
            }

            /////////////////////////////////////////////////////////////////////////////////////////////////////
            var query5 = (from ag in _context.accountgroups
                         join k in _context.kolaccounts on ag.AccountGroupID equals k.AccountGroupID
                         join m in _context.moeenaccounts on k.KolAccountID equals m.KolAccountID
                         join ft in _context.firsttafziliaccounts on m.MoeenAccountID equals ft.MoeenAccountID
                         join st in _context.secondtafziliaccounts on ft.FirstTafziliAccountID equals st.FirstTafziliAccountID
                         select new
                         {
                             ag.AccountGroupID,
                             ag.AccountGroupName,
                             k.KolAccountID,
                             k.KolAccountName,
                             m.MoeenAccountID,
                             m.MoeenAccountName,
                             ft.FirstTafziliAccountID,
                             ft.FirstTafziliAccountName,
                             st.SecondTafziliAccountID,
                             st.SecondTafziliAccountName

                         });

            foreach (var item in query5)
            {
                AddAccountViewModel objmodel = new AddAccountViewModel();
                objmodel.AccountGroupID = item.AccountGroupID;
                objmodel.AccountGroupName = item.AccountGroupName;
                objmodel.KolAccountID = item.KolAccountID;
                objmodel.KolAccountName = item.KolAccountName;
                objmodel.MoeenAccountID = item.MoeenAccountID;
                objmodel.MoeenAccountName = item.MoeenAccountName;
                objmodel.FirstTafziliAccountID = item.FirstTafziliAccountID;
                objmodel.FirstTafziliAccountName = item.FirstTafziliAccountName;
                objmodel.SecondTafziliAccountID = item.SecondTafziliAccountID;
                objmodel.SecondTafziliAccountName = item.SecondTafziliAccountName;

                model.Add(objmodel);
            }

            ////////////////////////////////////////////////////////////////////////////////////////////////////
            var query = (from ag in _context.accountgroups
                          join k in _context.kolaccounts on ag.AccountGroupID equals k.AccountGroupID
                          join m in _context.moeenaccounts on k.KolAccountID equals m.KolAccountID
                          join ft in _context.firsttafziliaccounts on m.MoeenAccountID equals ft.MoeenAccountID
                          join st in _context.secondtafziliaccounts on ft.FirstTafziliAccountID equals st.FirstTafziliAccountID
                          join tt in _context.thirdtafziliaccounts on st.SecondTafziliAccountID equals tt.SecondTafziliAccountID
                          select new
                          {
                              ag.AccountGroupID,
                              ag.AccountGroupName,
                              k.KolAccountID,
                              k.KolAccountName,
                              m.MoeenAccountID,
                              m.MoeenAccountName,
                              ft.FirstTafziliAccountID,
                              ft.FirstTafziliAccountName,
                              st.SecondTafziliAccountID,
                              st.SecondTafziliAccountName,
                              tt.ThirdTafziliAccountID,
                              tt.ThirdTafziliAccountName

                          });

            foreach (var item in query)
            {
                AddAccountViewModel objmodel = new AddAccountViewModel();
                objmodel.AccountGroupID = item.AccountGroupID;
                objmodel.AccountGroupName = item.AccountGroupName;
                objmodel.KolAccountID = item.KolAccountID;
                objmodel.KolAccountName = item.KolAccountName;
                objmodel.MoeenAccountID = item.MoeenAccountID;
                objmodel.MoeenAccountName = item.MoeenAccountName;
                objmodel.FirstTafziliAccountID = item.FirstTafziliAccountID;
                objmodel.FirstTafziliAccountName = item.FirstTafziliAccountName;
                objmodel.SecondTafziliAccountID = item.SecondTafziliAccountID;
                objmodel.SecondTafziliAccountName = item.SecondTafziliAccountName;
                objmodel.ThirdTafziliAccountID = item.ThirdTafziliAccountID;
                objmodel.ThirdTafziliAccountName = item.ThirdTafziliAccountName;

                model.Add(objmodel);
            }

            return View(model);

        }
    }
}