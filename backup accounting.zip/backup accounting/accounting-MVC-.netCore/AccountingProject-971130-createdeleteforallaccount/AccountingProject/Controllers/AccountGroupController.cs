using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AccountingProject.Models;
using Microsoft.Extensions.DependencyInjection;

namespace AccountingProject.Controllers
{
    public class AccountGroupController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceprovider;
        public AccountGroupController(ApplicationDbContext context, IServiceProvider iserviceprovider)
        {
            _context = context;
            _iserviceprovider = iserviceprovider;
        }
        [HttpGet]
        public IActionResult Index()
        {
            List<AccountGroup> model = new List<AccountGroup>();
            model = _context.accountgroups.Select(ag => new AccountGroup
            {
                AccountGroupID=ag.AccountGroupID,
                AccountGroupName=ag.AccountGroupName
            }).ToList();
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddAccountGroup(AccountGroup model, int Id)
        {
            if (ModelState.IsValid)
            {
                if (Id == 0)
                {
                    using (var db = _iserviceprovider.GetRequiredService<ApplicationDbContext>())
                    {
                        db.accountgroups.Add(model);
                        db.SaveChanges();
                    }
                    return RedirectToAction("ShowListAccount", "Account");
                }
                else
                {
                    using (var db = _iserviceprovider.GetRequiredService<ApplicationDbContext>())
                    {
                        db.accountgroups.Update(model);
                        db.SaveChanges();

                    }
                    return RedirectToAction("ShowListAccount", "Account");

                }

            }
            else
            {

                return PartialView("_AddEditAccountGroup", model);

            }
        }
    }
}