using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AccountingProject.Models.ViewModels;
using AccountingProject.Models;

namespace AccountingProject.Controllers
{
    public class BooksReportController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceprovider;
        public BooksReportController(ApplicationDbContext context, IServiceProvider iserviceprovider)
        {
            _context = context;
            _iserviceprovider = iserviceprovider;
        }


        [HttpGet]
        public IActionResult Index()
        {
            AddAccountViewModel model = new AddAccountViewModel();

            model.AccountGroup = _context.accountgroups.ToList();
            model.KolAccount = _context.kolaccounts.ToList();
            model.MoeenAccount = _context.moeenaccounts.ToList();
            model.FirstTafziliAccount = _context.firsttafziliaccounts.ToList();
            model.SecondTafziliAccount = _context.secondtafziliaccounts.ToList();
            model.ThirdTafziliAccount = _context.thirdtafziliaccounts.ToList();

            //ViewBag.AccountGroup = _context.accountgroups.ToList();
            //ViewBag.KolAccount = _context.kolaccounts.ToList();
            //ViewBag.MoeenAccount = _context.moeenaccounts.ToList();
            //ViewBag.FirstTafziliAccount = _context.firsttafziliaccounts.ToList();
            //ViewBag.SecondTafziliAccount = _context.secondtafziliaccounts.ToList();


            return View(model);
        }
    }
}