﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AccountingProject.Models;
using AccountingProject.Models.ViewModels;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AccountingProject.Controllers
{
    public class CreateAccountingDocumentController : Controller
    {
        // GET: /<controller>/
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceprovider;
        public CreateAccountingDocumentController(ApplicationDbContext context, IServiceProvider iserviceprovider)
        {
            _context = context;
            _iserviceprovider = iserviceprovider;
        }

        [HttpGet]
        public IActionResult Index()
        {
            AddAccountViewModel model = new AddAccountViewModel();

            model.AccountGroup = _context.accountgroups.ToList();
            model.KolAccount = _context.kolaccounts.ToList();
            model.MoeenAccount = _context.moeenaccounts.ToList();
            model.FirstTafziliAccount = _context.firsttafziliaccounts.ToList();
            model.SecondTafziliAccount = _context.secondtafziliaccounts.ToList();
            model.ThirdTafziliAccount = _context.thirdtafziliaccounts.ToList();

            //ViewBag.AccountGroup = _context.accountgroups.ToList();
            //ViewBag.KolAccount = _context.kolaccounts.ToList();
            //ViewBag.MoeenAccount = _context.moeenaccounts.ToList();
            //ViewBag.FirstTafziliAccount = _context.firsttafziliaccounts.ToList();
            //ViewBag.SecondTafziliAccount = _context.secondtafziliaccounts.ToList();


            return View(model);
        }
    }
}
