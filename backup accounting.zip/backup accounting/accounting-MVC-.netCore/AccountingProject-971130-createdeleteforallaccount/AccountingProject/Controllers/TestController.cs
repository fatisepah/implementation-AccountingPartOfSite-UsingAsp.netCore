using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AccountingProject.Models;
using AccountingProject.Models.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.DependencyInjection;

namespace AccountingProject.Controllers
{
    public class TestController : Controller
    {
        public TestController()
        {
        }

        [HttpGet]
        public IActionResult GetReport()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public string GetReeport(string reportType, string Name, int num)
        {
            return $"{reportType} - {Name} - {num}";
        }



    }
    
}