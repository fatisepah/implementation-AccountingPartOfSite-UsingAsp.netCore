﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace AccountingProject.Migrations
{
    public partial class createnewdatabase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "accountgroups",
                columns: table => new
                {
                    AccountGroupID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AccountGroupName = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_accountgroups", x => x.AccountGroupID);
                });

            migrationBuilder.CreateTable(
                name: "accountingdocuments",
                columns: table => new
                {
                    AccountingDocumentID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AccountingDocumentDate = table.Column<DateTime>(nullable: false),
                    DocumentDescription = table.Column<string>(nullable: false),
                    DocumentStatus = table.Column<string>(nullable: false),
                    Regularizer = table.Column<string>(nullable: true),
                    SumOfCreditorAccount = table.Column<int>(nullable: false),
                    SumOfDebtorAccount = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_accountingdocuments", x => x.AccountingDocumentID);
                });

            migrationBuilder.CreateTable(
                name: "accountviewmodels",
                columns: table => new
                {
                    AccountID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AccountGroupID = table.Column<int>(nullable: false),
                    AccountGroupName = table.Column<string>(nullable: false),
                    FirstTafziliAccountID = table.Column<int>(nullable: false),
                    FirstTafziliAccountName = table.Column<string>(nullable: false),
                    KolAccountID = table.Column<int>(nullable: false),
                    KolAccountName = table.Column<string>(nullable: false),
                    MoeenAccountID = table.Column<int>(nullable: false),
                    MoeenAccountName = table.Column<string>(nullable: false),
                    SecondTafziliAccountID = table.Column<int>(nullable: false),
                    SecondTafziliAccountName = table.Column<string>(nullable: false),
                    ThirdTafziliAccountID = table.Column<int>(nullable: false),
                    ThirdTafziliAccountName = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_accountviewmodels", x => x.AccountID);
                });

            migrationBuilder.CreateTable(
                name: "kolaccounts",
                columns: table => new
                {
                    KolAccountID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AccountGroupID = table.Column<int>(nullable: false),
                    KolAccountName = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_kolaccounts", x => x.KolAccountID);
                    table.ForeignKey(
                        name: "FK_kolaccounts_accountgroups_AccountGroupID",
                        column: x => x.AccountGroupID,
                        principalTable: "accountgroups",
                        principalColumn: "AccountGroupID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "documentaccounts",
                columns: table => new
                {
                    DocumentAccountsID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AccountID = table.Column<int>(nullable: false),
                    AccountingDocumentID = table.Column<int>(nullable: false),
                    AmountOfCredit = table.Column<int>(nullable: false),
                    AmountOfDebt = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_documentaccounts", x => x.DocumentAccountsID);
                    table.ForeignKey(
                        name: "FK_documentaccounts_accountviewmodels_AccountID",
                        column: x => x.AccountID,
                        principalTable: "accountviewmodels",
                        principalColumn: "AccountID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_documentaccounts_accountingdocuments_AccountingDocumentID",
                        column: x => x.AccountingDocumentID,
                        principalTable: "accountingdocuments",
                        principalColumn: "AccountingDocumentID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "moeenaccounts",
                columns: table => new
                {
                    MoeenAccountID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    KolAccountID = table.Column<int>(nullable: false),
                    MoeenAccountName = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_moeenaccounts", x => x.MoeenAccountID);
                    table.ForeignKey(
                        name: "FK_moeenaccounts_kolaccounts_KolAccountID",
                        column: x => x.KolAccountID,
                        principalTable: "kolaccounts",
                        principalColumn: "KolAccountID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "kolbooks",
                columns: table => new
                {
                    KolBookID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CirculationOfCredit = table.Column<int>(nullable: false),
                    CirculationOfDebt = table.Column<int>(nullable: false),
                    DocumentAccountsID = table.Column<int>(nullable: false),
                    Remain = table.Column<int>(nullable: false),
                    debtorcredit = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_kolbooks", x => x.KolBookID);
                    table.ForeignKey(
                        name: "FK_kolbooks_documentaccounts_DocumentAccountsID",
                        column: x => x.DocumentAccountsID,
                        principalTable: "documentaccounts",
                        principalColumn: "DocumentAccountsID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "firsttafziliaccounts",
                columns: table => new
                {
                    FirstTafziliAccountID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FirstTafziliAccountName = table.Column<string>(nullable: false),
                    MoeenAccountID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_firsttafziliaccounts", x => x.FirstTafziliAccountID);
                    table.ForeignKey(
                        name: "FK_firsttafziliaccounts_moeenaccounts_MoeenAccountID",
                        column: x => x.MoeenAccountID,
                        principalTable: "moeenaccounts",
                        principalColumn: "MoeenAccountID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "secondtafziliaccounts",
                columns: table => new
                {
                    SecondTafziliAccountID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FirstTafziliAccountID = table.Column<int>(nullable: false),
                    SecondTafziliAccountName = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_secondtafziliaccounts", x => x.SecondTafziliAccountID);
                    table.ForeignKey(
                        name: "FK_secondtafziliaccounts_firsttafziliaccounts_FirstTafziliAccountID",
                        column: x => x.FirstTafziliAccountID,
                        principalTable: "firsttafziliaccounts",
                        principalColumn: "FirstTafziliAccountID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "thirdtafziliaccounts",
                columns: table => new
                {
                    ThirdTafziliAccountID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    SecondTafziliAccountID = table.Column<int>(nullable: false),
                    ThirdTafziliAccountName = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_thirdtafziliaccounts", x => x.ThirdTafziliAccountID);
                    table.ForeignKey(
                        name: "FK_thirdtafziliaccounts_secondtafziliaccounts_SecondTafziliAccountID",
                        column: x => x.SecondTafziliAccountID,
                        principalTable: "secondtafziliaccounts",
                        principalColumn: "SecondTafziliAccountID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_documentaccounts_AccountID",
                table: "documentaccounts",
                column: "AccountID");

            migrationBuilder.CreateIndex(
                name: "IX_documentaccounts_AccountingDocumentID",
                table: "documentaccounts",
                column: "AccountingDocumentID");

            migrationBuilder.CreateIndex(
                name: "IX_firsttafziliaccounts_MoeenAccountID",
                table: "firsttafziliaccounts",
                column: "MoeenAccountID");

            migrationBuilder.CreateIndex(
                name: "IX_kolaccounts_AccountGroupID",
                table: "kolaccounts",
                column: "AccountGroupID");

            migrationBuilder.CreateIndex(
                name: "IX_kolbooks_DocumentAccountsID",
                table: "kolbooks",
                column: "DocumentAccountsID");

            migrationBuilder.CreateIndex(
                name: "IX_moeenaccounts_KolAccountID",
                table: "moeenaccounts",
                column: "KolAccountID");

            migrationBuilder.CreateIndex(
                name: "IX_secondtafziliaccounts_FirstTafziliAccountID",
                table: "secondtafziliaccounts",
                column: "FirstTafziliAccountID");

            migrationBuilder.CreateIndex(
                name: "IX_thirdtafziliaccounts_SecondTafziliAccountID",
                table: "thirdtafziliaccounts",
                column: "SecondTafziliAccountID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "kolbooks");

            migrationBuilder.DropTable(
                name: "thirdtafziliaccounts");

            migrationBuilder.DropTable(
                name: "documentaccounts");

            migrationBuilder.DropTable(
                name: "secondtafziliaccounts");

            migrationBuilder.DropTable(
                name: "accountviewmodels");

            migrationBuilder.DropTable(
                name: "accountingdocuments");

            migrationBuilder.DropTable(
                name: "firsttafziliaccounts");

            migrationBuilder.DropTable(
                name: "moeenaccounts");

            migrationBuilder.DropTable(
                name: "kolaccounts");

            migrationBuilder.DropTable(
                name: "accountgroups");
        }
    }
}
