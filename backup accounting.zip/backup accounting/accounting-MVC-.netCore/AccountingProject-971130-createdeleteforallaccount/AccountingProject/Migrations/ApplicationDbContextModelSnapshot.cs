﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using AccountingProject.Models;

namespace AccountingProject.Migrations
{
    [DbContext(typeof(ApplicationDbContext))]
    partial class ApplicationDbContextModelSnapshot : ModelSnapshot
    {
        protected override void BuildModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.1.2")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("AccountingProject.Models.AccountGroup", b =>
                {
                    b.Property<int>("AccountGroupID")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("AccountGroupCode");

                    b.Property<string>("AccountGroupName")
                        .IsRequired();

                    b.HasKey("AccountGroupID");

                    b.ToTable("accountgroups");
                });

            modelBuilder.Entity("AccountingProject.Models.AccountingDocument", b =>
                {
                    b.Property<int>("AccountingDocumentID")
                        .ValueGeneratedOnAdd();

                    b.Property<DateTime>("AccountingDocumentDate");

                    b.Property<string>("DocumentDescription")
                        .IsRequired();

                    b.Property<string>("DocumentStatus")
                        .IsRequired();

                    b.Property<string>("Regularizer");

                    b.Property<int>("SumOfCreditorAccount");

                    b.Property<int>("SumOfDebtorAccount");

                    b.HasKey("AccountingDocumentID");

                    b.ToTable("accountingdocuments");
                });

            modelBuilder.Entity("AccountingProject.Models.DocumentAccounts", b =>
                {
                    b.Property<int>("DocumentAccountsID")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("AccountingDocumentID");

                    b.Property<int>("AmountOfCredit");

                    b.Property<int>("AmountOfDebt");

                    b.HasKey("DocumentAccountsID");

                    b.HasIndex("AccountingDocumentID");

                    b.ToTable("documentaccounts");
                });

            modelBuilder.Entity("AccountingProject.Models.FirstTafziliAccount", b =>
                {
                    b.Property<int>("FirstTafziliAccountID")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("FirstTafziliAccountCode");

                    b.Property<string>("FirstTafziliAccountName")
                        .IsRequired();

                    b.Property<int>("MoeenAccountID");

                    b.HasKey("FirstTafziliAccountID");

                    b.HasIndex("MoeenAccountID");

                    b.ToTable("firsttafziliaccounts");
                });

            modelBuilder.Entity("AccountingProject.Models.KolAccount", b =>
                {
                    b.Property<int>("KolAccountID")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("AccountGroupID");

                    b.Property<int>("KolAccountCode");

                    b.Property<string>("KolAccountName")
                        .IsRequired();

                    b.HasKey("KolAccountID");

                    b.HasIndex("AccountGroupID");

                    b.ToTable("kolaccounts");
                });

            modelBuilder.Entity("AccountingProject.Models.KolBook", b =>
                {
                    b.Property<int>("KolBookID")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("CirculationOfCredit");

                    b.Property<int>("CirculationOfDebt");

                    b.Property<int>("DocumentAccountsID");

                    b.Property<int>("Remain");

                    b.Property<string>("debtorcredit")
                        .IsRequired();

                    b.HasKey("KolBookID");

                    b.HasIndex("DocumentAccountsID");

                    b.ToTable("kolbooks");
                });

            modelBuilder.Entity("AccountingProject.Models.MoeenAccount", b =>
                {
                    b.Property<int>("MoeenAccountID")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("KolAccountID");

                    b.Property<int>("MoeenAccountCode");

                    b.Property<string>("MoeenAccountName")
                        .IsRequired();

                    b.HasKey("MoeenAccountID");

                    b.HasIndex("KolAccountID");

                    b.ToTable("moeenaccounts");
                });

            modelBuilder.Entity("AccountingProject.Models.SecondTafziliAccount", b =>
                {
                    b.Property<int>("SecondTafziliAccountID")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("FirstTafziliAccountID");

                    b.Property<int>("SecondTafziliAccountCode");

                    b.Property<string>("SecondTafziliAccountName")
                        .IsRequired();

                    b.HasKey("SecondTafziliAccountID");

                    b.HasIndex("FirstTafziliAccountID");

                    b.ToTable("secondtafziliaccounts");
                });

            modelBuilder.Entity("AccountingProject.Models.ThirdTafziliAccount", b =>
                {
                    b.Property<int>("ThirdTafziliAccountID")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("SecondTafziliAccountID");

                    b.Property<int>("ThirdTafziliAccountCode");

                    b.Property<string>("ThirdTafziliAccountName")
                        .IsRequired();

                    b.HasKey("ThirdTafziliAccountID");

                    b.HasIndex("SecondTafziliAccountID");

                    b.ToTable("thirdtafziliaccounts");
                });

            modelBuilder.Entity("AccountingProject.Models.DocumentAccounts", b =>
                {
                    b.HasOne("AccountingProject.Models.AccountingDocument", "accountingdocuments")
                        .WithMany()
                        .HasForeignKey("AccountingDocumentID")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("AccountingProject.Models.FirstTafziliAccount", b =>
                {
                    b.HasOne("AccountingProject.Models.MoeenAccount", "moeenaccounts")
                        .WithMany()
                        .HasForeignKey("MoeenAccountID")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("AccountingProject.Models.KolAccount", b =>
                {
                    b.HasOne("AccountingProject.Models.AccountGroup", "accountgroups")
                        .WithMany()
                        .HasForeignKey("AccountGroupID")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("AccountingProject.Models.KolBook", b =>
                {
                    b.HasOne("AccountingProject.Models.DocumentAccounts", "documentaccounts")
                        .WithMany()
                        .HasForeignKey("DocumentAccountsID")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("AccountingProject.Models.MoeenAccount", b =>
                {
                    b.HasOne("AccountingProject.Models.KolAccount", "kolaccounts")
                        .WithMany()
                        .HasForeignKey("KolAccountID")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("AccountingProject.Models.SecondTafziliAccount", b =>
                {
                    b.HasOne("AccountingProject.Models.FirstTafziliAccount", "firsttafziliaccounts")
                        .WithMany()
                        .HasForeignKey("FirstTafziliAccountID")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("AccountingProject.Models.ThirdTafziliAccount", b =>
                {
                    b.HasOne("AccountingProject.Models.SecondTafziliAccount", "secondtafziliaccounts")
                        .WithMany()
                        .HasForeignKey("SecondTafziliAccountID")
                        .OnDelete(DeleteBehavior.Cascade);
                });
        }
    }
}
