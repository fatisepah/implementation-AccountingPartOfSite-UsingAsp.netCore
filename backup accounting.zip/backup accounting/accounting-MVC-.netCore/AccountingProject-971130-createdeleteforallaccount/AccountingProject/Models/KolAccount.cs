﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AccountingProject.Models
{
    public class KolAccount
    {
        [Key]
        public int KolAccountID { get; set; }


        [Display(Name = "کد حساب کل")]
        [Required(ErrorMessage = "لطفا کد حساب کل را وارد کنید.")]
        public int KolAccountCode { get; set; }


        [Display(Name = "نام حساب کل")]
        [Required(ErrorMessage = "لطفا نام حساب کل را وارد کنید.")]
        public string KolAccountName { get; set; }


        //foriegn key for AccountGroup table
        public int AccountGroupID { get; set; }
        [ForeignKey("AccountGroupID")]
        public virtual AccountGroup accountgroups { get; set; }

    }
}
