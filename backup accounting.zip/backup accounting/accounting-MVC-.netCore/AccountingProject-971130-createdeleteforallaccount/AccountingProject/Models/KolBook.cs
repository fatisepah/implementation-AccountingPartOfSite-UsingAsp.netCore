﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AccountingProject.Models
{
    public class KolBook
    {
        [Key]
        public int KolBookID { get; set; }


        //foriegn key for AccountingDocument table
        public int DocumentAccountsID { get; set; }
        [ForeignKey("DocumentAccountsID")]
        public virtual DocumentAccounts documentaccounts { get; set; }



        [Display(Name = "گردش بدهکار :")]
        [Required(ErrorMessage = "لطفا گردش بدهکار را وارد کنید.")]
        public int CirculationOfDebt { get; set; }


        [Display(Name = "گردش بستانکار :")]
        [Required(ErrorMessage = "لطفا گردش بستانکار را وارد کنید.")]
        public int CirculationOfCredit { get; set; }


        [Display(Name = "مانده :")]
        [Required(ErrorMessage = "لطفا مانده را وارد کنید.")]
        public int Remain { get; set; }


        [Display(Name = "تشخیص :")]
        [Required(ErrorMessage = "لطفا تشخیص را وارد کنید.")]
        public string debtorcredit { get; set; }
    }
}
