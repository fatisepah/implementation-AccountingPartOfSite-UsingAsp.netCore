﻿using System;

namespace AccountingProject.Models
{
    internal class displayAttribute : Attribute
    {
    }
}