﻿(function ($) {
    function KolAccount() {
        var $this = this;

        function initilizeModel() {
            $("#kolaccount").on('loaded.bs.modal', function (e) {

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });
        }
        $this.init = function () {
            initilizeModel();
        }
    }
    $(function () {
        var self = new KolAccount();
        self.init();
    })
}(jQuery))